CREATE TABLE User_info(
username char(20) not null  primary key,
password char(20) not null ,
Email char(100) not null,
Location char (100) not null
)