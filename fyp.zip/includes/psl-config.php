<?php

    session_start();
    define("HOST","localhost");
    define("USER","root");
    define("PASSWORD","password");
    define("DATABASE","mysql");

    define("CAN_REGISTER","any");
    define("DEFAULT_ROLE","member");
    define("SECURE",FALSE);
?>
    